#include<ros/ros.h>
#include<turtlesim/Spawn.h>

int main(int argc,char **argv){
    ros::init(argc,argv,"turtle_b");

    ros::NodeHandle node;

    ros::service::waitForService("/spawn");
    ros::ServiceClient add_turtle_b = node.serviceClient<turtlesim::Spawn>("/spawn");

    turtlesim::Spawn b;
    b.request.x=8.2;
    b.request.y=5;
    b.request.name="turtleb";

    ROS_INFO("Call service to spawn turtle_b[x:%0.6f,y:%0.6f,name:%s]",b.request.x,b.request.y,b.request.name.c_str());

    add_turtle_b.call(b);

    return 0;
}
