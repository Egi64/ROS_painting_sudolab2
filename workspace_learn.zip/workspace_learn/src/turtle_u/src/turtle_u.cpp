#include<ros/ros.h>
#include<turtlesim/Spawn.h>

int main(int argc,char **argv){
    ros::init(argc,argv,"turtle_u");

    ros::NodeHandle node;

    ros::service::waitForService("/spawn");
    ros::ServiceClient add_turtle_u = node.serviceClient<turtlesim::Spawn>("/spawn");

    turtlesim::Spawn u;
    u.request.x=3.3;
    u.request.y=8.6;
    u.request.name="turtleu";

    ROS_INFO("Call service to spawn turtle_u[x:%0.6f,y:%0.6f,name:%s]",u.request.x,u.request.y,u.request.name.c_str());

    add_turtle_u.call(u);

    return 0;
}
