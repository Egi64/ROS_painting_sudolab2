#include<ros/ros.h>
#include<std_srvs/Empty.h>

int main(int argc,char **argv){
    ros::init(argc,argv,"turtle_clear");

    ros::NodeHandle node;

    ros::service::waitForService("/clear");
    ros::ServiceClient add_turtle = node.serviceClient<std_srvs::Empty>("/clear");

    std_srvs::Empty srv;
    
    add_turtle.call(srv);

    return 0;
}
