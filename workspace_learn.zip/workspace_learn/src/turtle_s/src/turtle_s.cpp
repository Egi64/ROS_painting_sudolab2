#include<ros/ros.h>
#include<turtlesim/Spawn.h>

int main(int argc,char **argv){
    ros::init(argc,argv,"turtle_s");

    ros::NodeHandle node;

    ros::service::waitForService("/spawn");
    ros::ServiceClient add_turtle_s = node.serviceClient<turtlesim::Spawn>("/spawn");

    turtlesim::Spawn s;
    s.request.x=1.6;
    s.request.y=5.8;
    s.request.name="turtles";

    ROS_INFO("Call service to spawn turtle_s[x:%0.6f,y:%0.6f,name:%s]",s.request.x,s.request.y,s.request.name.c_str());

    add_turtle_s.call(s);

    return 0;
}
