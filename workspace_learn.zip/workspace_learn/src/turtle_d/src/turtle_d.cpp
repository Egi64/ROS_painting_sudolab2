#include<ros/ros.h>
#include<turtlesim/Spawn.h>

int main(int argc,char **argv){
    ros::init(argc,argv,"turtle_d");

    ros::NodeHandle node;

    ros::service::waitForService("/spawn");
    ros::ServiceClient add_turtle_d = node.serviceClient<turtlesim::Spawn>("/spawn");

    turtlesim::Spawn d;
    d.request.x=7;
    d.request.y=8;
    d.request.name="turtled";

    ROS_INFO("Call service to spawn turtle_d[x:%0.6f,y:%0.6f,name:%s]",d.request.x,d.request.y,d.request.name.c_str());

    add_turtle_d.call(d);

    return 0;
}
