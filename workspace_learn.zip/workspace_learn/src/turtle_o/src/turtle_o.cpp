#include<ros/ros.h>
#include<turtlesim/Spawn.h>

int main(int argc,char **argv){
    ros::init(argc,argv,"turtle_o");

    ros::NodeHandle node;

    ros::service::waitForService("/spawn");
    ros::ServiceClient add_turtle_o = node.serviceClient<turtlesim::Spawn>("/spawn");

    turtlesim::Spawn o;
    o.request.x=9.5;
    o.request.y=6.3;
    o.request.name="turtleo";

    ROS_INFO("Call service to spawn turtle_o[x:%0.6f,y:%0.6f,name:%s]",o.request.x,o.request.y,o.request.name.c_str());

    add_turtle_o.call(o);

    return 0;
}
