#include<ros/ros.h>
#include<geometry_msgs/Twist.h>

int main(int argc,char **argv){

    ros::init(argc,argv,"first");

    ros::NodeHandle n;

    ros::Publisher turtle_vel_pub = n.advertise<geometry_msgs::Twist>("/turtle1/cmd_vel",10);

    ros::Rate loop_rate(2);

    double PI=3.1415926535897932;
    int count=1;
    while(ros::ok()){
        loop_rate.sleep();

        geometry_msgs::Twist vel_msgs;
        if(count==1){
            vel_msgs.linear.x=0;
            vel_msgs.angular.z=-PI;
        }
        if(count==2){
            vel_msgs.linear.x=2.7;
            vel_msgs.angular.z=0;
        }
        if(count==3){
            vel_msgs.linear.x=0;
            vel_msgs.angular.z=PI;
        }
        count++;
        turtle_vel_pub.publish(vel_msgs);
    }
    return 0;
}
