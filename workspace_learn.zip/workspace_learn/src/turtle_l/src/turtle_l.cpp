#include<ros/ros.h>
#include<turtlesim/Spawn.h>

int main(int argc,char **argv){
    ros::init(argc,argv,"turtle_l");

    ros::NodeHandle node;

    ros::service::waitForService("/spawn");
    ros::ServiceClient add_turtle_l = node.serviceClient<turtlesim::Spawn>("/spawn");

    turtlesim::Spawn l;
    l.request.x=2;
    l.request.y=5;
    l.request.name="turtlel";

    ROS_INFO("Call service to spawn turtle_l[x:%0.6f,y:%0.6f,name:%s]",l.request.x,l.request.y,l.request.name.c_str());

    add_turtle_l.call(l);

    return 0;
}
